---
name: '#6 Redux Requirement'
about: Issue for the Redux requirement
title: State management is done through Redux
labels: ''
assignees: ''
---

The React app contains an implementation of Redux for state management that:

- [ ] a store to manage all of the data
- [ ] action(s) for sending information
- [ ] reducer(s) for handling application state changes
